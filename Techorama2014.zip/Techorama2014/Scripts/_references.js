﻿/// <reference path="modernizr-2.7.2.js" />
/// <reference path="jquery-2.1.1.js" />
/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="respond.js" />
