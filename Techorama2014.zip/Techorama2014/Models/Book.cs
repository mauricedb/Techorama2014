﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Techorama2014.Models
{
    public class Book
    {
        [ReadOnly(true)]
        public int Id { get; set; }

        [Required]
        [DisplayName("Title")]
        public string BookTitle { get; set; }

        [Required]
        public string Author { get; set; }

        [DisplayName("Image")]
        public string ImageName { get; set; }
    }
}